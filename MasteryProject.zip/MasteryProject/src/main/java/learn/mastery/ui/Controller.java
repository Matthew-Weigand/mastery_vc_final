package learn.mastery.ui;

import learn.mastery.data.DataException;
import learn.mastery.domain.ReservationService;
import learn.mastery.domain.Result;
import learn.mastery.models.Reservation;

import javax.xml.crypto.Data;
import java.io.FileNotFoundException;
import java.util.List;

public class Controller {

    private final ReservationService reservationService;
    private final View view;

    public Controller(ReservationService reservationService, View view) {
        this.reservationService = reservationService;
        this.view = view;
    }

    public void run() {
        view.displayHeader("Don't Wreck My House");
        try {
            runAppLoop();
        } catch (DataException | FileNotFoundException e) {

        }
        view.displayHeader("Hope you enjoy your stay!");
    }


    private void runAppLoop() throws DataException, FileNotFoundException {
        MenuOptions option;
        do {
            option = view.selectMainMenuOption();
            switch (option) {
                case VIEW_RESERVATIONS_BY_HOST:
                    viewByHost();
                    break;
                case MAKE_RESERVATION:
                    makeReservation();
                    break;
                case EDIT_RESERVATION:
                    //edit reservatoin
                    break;
                case CANCEL_RESERVATION:
                   cancelReservation();
                    break;
            }
        } while (option != MenuOptions.EXIT);
    }

    //responsible for driving the  view existing reservations for a host,
    //needs a host, which has-A list of reservations
    //                             creating reservations,
    //                             editing reservations,
    //                             and cancelling future reservations


    private void viewByHost() throws DataException{
        String locationId = view.getHostLocation();
        List<Reservation> reservations = reservationService.findByLocation(locationId);
        view.displayReservations(reservations);
        view.enterToContinue();
    }

    private void makeReservation() throws DataException {
        Reservation reservation = view.makeReservation();

        if(view.confirmReservation()){
            Result<Reservation> result = reservationService.add(reservation);

            if (!result.isSuccess()) {
                view.displayStatus(false, result.getErrorMessages());
            } else {
                String successMessage = String.format("Reservation %s was created", result.getPayload().getReservationId());
                view.displayStatus(true, successMessage);
            }
        }
        else{
            System.out.println("Reservation not placed. ");
        }

    }

    private void cancelReservation() throws DataException {

        Reservation reservation = view.cancelReservation();

        reservationService.cancel(reservation.getLocation().getLocationId(),reservation.getReservationId());

    }

}

