package learn.mastery.ui;


import learn.mastery.models.Guest;
import learn.mastery.models.Location;
import learn.mastery.models.Reservation;
import java.util.List;

public class View {

    private final ConsoleIO io;

    public View(ConsoleIO io) {
        this.io = io;
    }

    public MenuOptions selectMainMenuOption() {
        displayHeader("Main Menu");
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        for (MenuOptions option : MenuOptions.values()) {
            if (!option.isHidden()) {
                io.printf("%s. %s%n", option.getValue(), option.getMessage());
            }
            min = Math.min(min, option.getValue());
            max = Math.max(max, option.getValue());
        }

        String message = String.format("Select [%s-%s]: ", min, max);
        return MenuOptions.fromValue(io.readInt(message, min, max));
    }

    public void displayHeader(String message) {
        io.println("");
        io.println(message);
        io.println("=".repeat(message.length()));
    }

    public void enterToContinue() {
        io.readString("Press [Enter] to continue.");
    }

    public String getHostLocation() {
        displayHeader(MenuOptions.VIEW_RESERVATIONS_BY_HOST.getMessage());
        return io.readRequiredString("Enter Host ID: ");
    }

    public void displayReservations(List<Reservation> reservations) {
        if (reservations == null || reservations.isEmpty()) {
            io.println("No hosts found.");
            return;
        }
        for (Reservation reservation : reservations) {
            io.printf("Reservation ID: %s, %s - %s,  Guest ID: %s,  Total Cost of Stay: $%.2f%n",
                    reservation.getReservationId(),
                    reservation.getStartDate(),
                    reservation.getEndDate(),
                    reservation.getGuest().getId(),
                    reservation.getTotalCost()
            );
        }
    }

    public Reservation makeReservation() {
        Location location = new Location();
        Guest guest = new Guest();
        location.setLocationId(io.readRequiredString("Enter location id: "));
        guest.setId(io.readInt("Enter guest id: "));

        displayHeader(MenuOptions.MAKE_RESERVATION.getMessage());
        Reservation reservation = new Reservation();
        reservation.setLocation(location);
        reservation.setGuest(guest);
        reservation.setReservationId(io.readInt("Enter reservation ID"));
        reservation.setStartDate(io.readLocalDate("Enter start date: (yyyy-mm-dd) "));
        reservation.setEndDate(io.readLocalDate("Enter end date: (yyyy-mm-dd) "));
        reservation.setTotalCost(reservation.calculateTotal());
        System.out.println("Reservation Details: ");
        System.out.println("Start Date: " + reservation.getStartDate());
        System.out.println("End Date: " + reservation.getEndDate());
        System.out.println("Total cost: " + reservation.getTotalCost());

        return reservation;
    }

    public Reservation cancelReservation() {
        Location location = new Location();
        location.setLocationId(io.readRequiredString("Enter host location id: "));
        displayHeader(MenuOptions.CANCEL_RESERVATION.getMessage());
        Reservation reservation = new Reservation();
        reservation.setLocation(location);
        reservation.setReservationId(io.readInt("Enter reservation id to cancel"));

        return reservation;
    }

    public boolean confirmReservation() {
        String decision = io.readRequiredString("Would you like to place reservation? (yes/no) ");
        if (decision.equalsIgnoreCase("yes")) {
            return true;
        } else
            return false;
    }

    public void displayStatus(boolean success, String message) {
        displayStatus(success, List.of(message));
    }

    public void displayStatus(boolean success, List<String> messages) {
        displayHeader(success ? "Success" : "Error");
        for (String message : messages) {
            io.println(message);
        }
    }


}
