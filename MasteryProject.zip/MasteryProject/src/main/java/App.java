import learn.mastery.data.*;
import learn.mastery.domain.ReservationService;
import learn.mastery.ui.ConsoleIO;
import learn.mastery.ui.Controller;
import learn.mastery.ui.View;

public class App {
    public static void main(String[] args) {
        LocationFileRepository locationRepository = new LocationFileRepository("dont-wreck-my-house-data/locations.csv");
        ReservationFileRepository reservationRepository = new ReservationFileRepository("dont-wreck-my-house-data/reservations");
        GuestFileRepository guestRepository = new GuestFileRepository("dont-wreck-my-house-data/guests.csv");

        ConsoleIO io = new ConsoleIO();
        View view = new View(io);
        ReservationService service = new ReservationService(reservationRepository,locationRepository,guestRepository);

        Controller controller = new Controller(service, view);
        controller.run();

    }

}
